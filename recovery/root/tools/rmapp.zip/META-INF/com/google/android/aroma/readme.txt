<b><#selectbg_g>Script mod for MIUI/Custom by brigudav</#></b>

<b>Important:</b>
This debloater is not "Noob" proof, so think twice before check an app for removing.

I'm not responsible for any possible damage done to your device as a result of flashing.
I'll not take any responsibility for bricked phones or lost data.

If you are not willing to agree with these conditions, don't continue and abort the installation process.

<b><u>WARNING!</b></u>
If you'are about running that script, and delete system apps that will be downloaded as user apps,
be sure to run that script with the same settings to avoid app conflicts.

<b>Внимание:</b>
Два раза подумайте перед удалением приложений.

Я не несу ответственности за любой возможный ущерб, нанесенный вашему устройству.
Я не буду брать на себя ответственность за "кирпичи" или ваши потерянные данные.

Если вы не согласны с этими условиями, не продолжайте и не прервите процесс.

<b><u>ВНИМАНИЕ!</b></u>
Если вы хотите удалить системные приложения, которые будут загружаться в качестве пользовательских,
то не забудьте запустить этот скрипт с теми же настройками еще раз для избежания конфликтов.